var __wpo = {
  "assets": {
    "main": [
      "/895350db8b0406c20d3e79e550cf28bd.png",
      "/62e230ec98374b09f28ed2972760a7b5.jpg",
      "/9714ffabceeef9f1580b169cddf84fd9.png",
      "/912ec66d7572ff821749319396470bde.svg",
      "/8163277d0f88deb701e52cf94ffbf0cd.jpg",
      "/ab66619eb8a5d3477976e1979a950783.jpg",
      "/icon-512x512.png",
      "/aa2449a2c1e85da819ac504ecf93e4d3.jpg",
      "/0045c460e869c16457fc8842fa0f0b30.webp",
      "/0cb10ada7f9eaa6afdefedbf21c97eb2.png",
      "/b4b0a26a98e0a2cdbcdd8728db1fadf5.jpg",
      "/77a4d0da569abb202058212689d25d3e.jpg",
      "/da73a4b05ef4c11187763330119863c9.jpg",
      "/59afcba46625de3c0deefa3b11153abc.jpg",
      "/fee66e712a8a08eef5805a46892932ad.woff",
      "/f768108f51e4d92d4e2ce78d684a0d30.webp",
      "/1cc45063366c5129de6627b06a13697e.png",
      "/a5092052d8e129adf795b829b42a1885.jpg",
      "/aa7efae91d4afca3308347ea48892b39.jpg",
      "/ebf162e3713e2ce1b32e6d91e051cf36.jpg",
      "/72b5776c3c5f93ac1c7fdf672cfa3e57.webp",
      "/6fcb270d565bcfd21bfedf7e5985533a.jpg",
      "/c9c65e03d7b992bea6e1748616832104.ogg",
      "/b1939db8e89b93e2783d163232be6f19.jpg",
      "/eedadf8c8d03830638b8c15247c667af.svg",
      "/693eed2f1cce08a4b770c2cdaf5e622c.png",
      "/9774da3921235851828326ea33fb7e49.jpg",
      "/favicon.ico",
      "/674f50d287a8c48dc19ba404d20fe713.eot",
      "/2bd96b2b18adb7e5f299e2f01a5b942f.jpg",
      "/27a43fa8c46f56eb5d4810000c9b860a.webp",
      "/a9a20be1d38f90af9534e078fa12fe8e.jpg",
      "/c7acc9aa4d28cd4fc651f8d4d452ffaa.jpg",
      "/b8822a40af1ba60bcbb24f04575a6c58.jpg",
      "/b06871f281fee6b241d60582ae9369b9.ttf",
      "/879a1f2f87a879b9eb083d2ad2d1dbcd.png",
      "/b342990c5036c83704a14d745ab3ac89.webp",
      "/31f107bc030841ad069014900e30ddcd.jpg",
      "/86b7f48b89f89f0030c2ad99854b6428.jpg",
      "/250fe1cab1e2374f39a1f4470c6a177f.jpg",
      "/b53e67f187f8ff8fa985e6c3c6206f74.jpg",
      "/af7ae505a9eed503f8b8e6982036873e.woff2",
      "/ca00542358747732ab84b207f56ac54b.jpg",
      "/3388fd2c2f2de65bf67327a5d483c0c8.jpg",
      "/c9dd69953af7a0540c9a6cdc41115325.webp",
      "/runtime.eb52123d42dd1870a1e1.js",
      "/"
    ],
    "additional": [
      "/npm.intl.d3b309cd1f41ae274e7d.chunk.js",
      "/npm.reactstrap.de9f11bb3905fe6e30e7.chunk.js",
      "/main.b4ecebd475da58ba0a98.chunk.js",
      "/npm.babel.5432ced5571abfb0ced6.chunk.js",
      "/npm.css-vendor.c99415d9e30536988a67.chunk.js",
      "/npm.font-awesome.5bc19fe8483eebe2ea19.chunk.js",
      "/npm.intl-messageformat.1de3860bb6253e052c4a.chunk.js",
      "/npm.intl-relativeformat.8dd32a5e5a16117331c4.chunk.js",
      "/npm.jss.f441ce707c2086f4dbf8.chunk.js",
      "/npm.material-ui.47aa6a073ca053c6a6fd.chunk.js",
      "/npm.promise.733a52a4b24f86e30b32.chunk.js",
      "/npm.prop-types.00bbae956717cc1050e2.chunk.js",
      "/npm.react-app-polyfill.83ebef0577be4f8cc587.chunk.js",
      "/npm.react-intl.741dd49add785b9d27b0.chunk.js",
      "/15.f5be83ad214c3ce47e90.chunk.js",
      "/16.6034045e6580999510bb.chunk.js",
      "/17.d6848cc7cc19eb7fbec4.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "260bd4bdd0d6ed839cc363b966fe62a07c874e65": "/895350db8b0406c20d3e79e550cf28bd.png",
    "13433deb75f627447c1b91d79ffdbe9d33202a0a": "/62e230ec98374b09f28ed2972760a7b5.jpg",
    "ff27d62a66affe820c9d1f5b08ce459360e159de": "/9714ffabceeef9f1580b169cddf84fd9.png",
    "98a8aa5cf7d62c2eff5f07ede8d844b874ef06ed": "/912ec66d7572ff821749319396470bde.svg",
    "d7ebc27b049b873f7ea3d3e2ccc5eb18a4f85d14": "/8163277d0f88deb701e52cf94ffbf0cd.jpg",
    "b567c6451b8cb7cd9e60128164e8a0e37796b976": "/ab66619eb8a5d3477976e1979a950783.jpg",
    "e86d3d5fdb79a15f3e77920b3fea6202cbf96ca3": "/icon-512x512.png",
    "b2213c8fd56395159af0cdaaa4a3d707cb2c1ca4": "/aa2449a2c1e85da819ac504ecf93e4d3.jpg",
    "24c728b3f2fe19b801fac9c9f56eb818266d7e46": "/0045c460e869c16457fc8842fa0f0b30.webp",
    "b1443deb3a6c79baf35d0ffd7cd6d8881c281da3": "/0cb10ada7f9eaa6afdefedbf21c97eb2.png",
    "43f2eb95b17ba163fedc865a766353d7baf2b158": "/b4b0a26a98e0a2cdbcdd8728db1fadf5.jpg",
    "8495b4730a09cf251a09a52795ec4c697bdeb916": "/77a4d0da569abb202058212689d25d3e.jpg",
    "05da6a48251a7694fbfd4e4de7860090828c1ff2": "/da73a4b05ef4c11187763330119863c9.jpg",
    "2c7fe3b8b6b851c0f58ad34794280f8c1c2b3717": "/59afcba46625de3c0deefa3b11153abc.jpg",
    "28b782240b3e76db824e12c02754a9731a167527": "/fee66e712a8a08eef5805a46892932ad.woff",
    "76cefc47e60acf0cea14e0a7763169c246c9b67b": "/f768108f51e4d92d4e2ce78d684a0d30.webp",
    "13b47bc4654f60ce4e843b5cbaa95024415b71ee": "/1cc45063366c5129de6627b06a13697e.png",
    "fd6fb7e632fda006c0936ab87aff592a2dd62de5": "/a5092052d8e129adf795b829b42a1885.jpg",
    "71c116124c2a784a03a852cfd09598ea5b4e294f": "/aa7efae91d4afca3308347ea48892b39.jpg",
    "8aa20b3dce9848b09e4b80377023c6e44a3de371": "/ebf162e3713e2ce1b32e6d91e051cf36.jpg",
    "fce473e210e6366d6075c7bb2ee6c6f071fa893a": "/72b5776c3c5f93ac1c7fdf672cfa3e57.webp",
    "78dd44831f0f2b62227f7ae8e53134f1bcab5167": "/6fcb270d565bcfd21bfedf7e5985533a.jpg",
    "49b07dac851436e47d679a985e33687fe8c3f081": "/c9c65e03d7b992bea6e1748616832104.ogg",
    "616205dd15d05c0f034d024d5988c33cbd72a9e1": "/b1939db8e89b93e2783d163232be6f19.jpg",
    "420f0b97fca18193880bbf3a6ad220e103f85fb2": "/eedadf8c8d03830638b8c15247c667af.svg",
    "badbb062de7f07143eb130e821fff0743af73db9": "/693eed2f1cce08a4b770c2cdaf5e622c.png",
    "faf72d4c242d0b11337502cc5d3d5325b7a724ec": "/9774da3921235851828326ea33fb7e49.jpg",
    "349290be6f579e5d1025d063c64c520306d76ba7": "/favicon.ico",
    "d980c2ce873dc43af460d4d572d441304499f400": "/674f50d287a8c48dc19ba404d20fe713.eot",
    "c57b8ae8efbd0bc6323cc6c80daddd469de6cd03": "/2bd96b2b18adb7e5f299e2f01a5b942f.jpg",
    "665d4cb1c7301f8f359dbaa136ba5a7aa40df6b5": "/27a43fa8c46f56eb5d4810000c9b860a.webp",
    "c5868d882598b7bfb813639337492327bea04e11": "/a9a20be1d38f90af9534e078fa12fe8e.jpg",
    "0c4bfa9414000a06b1a9d884304b8fcc73934e1b": "/c7acc9aa4d28cd4fc651f8d4d452ffaa.jpg",
    "735cc923b958fd68fc7c93b06e894b572187a55e": "/b8822a40af1ba60bcbb24f04575a6c58.jpg",
    "13b1eab65a983c7a73bc7997c479d66943f7c6cb": "/b06871f281fee6b241d60582ae9369b9.ttf",
    "8c9ecd77b9a3253b02db5e8987781774c53878ad": "/879a1f2f87a879b9eb083d2ad2d1dbcd.png",
    "2fa4298d972cdc7533909432908d33c22424c792": "/b342990c5036c83704a14d745ab3ac89.webp",
    "0a5a30fce6e649c3b7ff2b662309b025293c9583": "/31f107bc030841ad069014900e30ddcd.jpg",
    "65aa6cdd537f5ff1611e224c282bdf6169b5aa62": "/86b7f48b89f89f0030c2ad99854b6428.jpg",
    "f4f8fde5f867da27a7e9fad8cc9f82e4ee3cec3f": "/250fe1cab1e2374f39a1f4470c6a177f.jpg",
    "967a1dccc3659bb7ac5b9de8b037ef37dfed6c64": "/b53e67f187f8ff8fa985e6c3c6206f74.jpg",
    "d6f48cba7d076fb6f2fd6ba993a75b9dc1ecbf0c": "/af7ae505a9eed503f8b8e6982036873e.woff2",
    "22657a2614a5a547f5279aa8147efd238b886e27": "/ca00542358747732ab84b207f56ac54b.jpg",
    "6bd7c7539fab8789161769b3c63442de58da07b0": "/3388fd2c2f2de65bf67327a5d483c0c8.jpg",
    "f50804882a2843c7dbb3c37c18b1a32ab5755a8a": "/c9dd69953af7a0540c9a6cdc41115325.webp",
    "1e7fd4463861aeb6a378cf7fb56273f34f47d204": "/npm.intl.d3b309cd1f41ae274e7d.chunk.js",
    "4ea89154e729ee4c9a363e10a0fc2066d4d19ad9": "/npm.reactstrap.de9f11bb3905fe6e30e7.chunk.js",
    "bc857cdbdb850afff9978aa344e5d7483e9e0ec4": "/main.b4ecebd475da58ba0a98.chunk.js",
    "136be14d50b73605c1445d1b1988c5007da4e1f4": "/npm.babel.5432ced5571abfb0ced6.chunk.js",
    "795158c486eb4a2f4393138c02c00fd15ad56732": "/npm.css-vendor.c99415d9e30536988a67.chunk.js",
    "93e0058184972846e47007695bfb0add99c1d506": "/npm.font-awesome.5bc19fe8483eebe2ea19.chunk.js",
    "7f249fa9a9bbb9eabd21726c0840f0dcd502a293": "/npm.intl-messageformat.1de3860bb6253e052c4a.chunk.js",
    "1f0b87d2ba64df8d794ac3304ff300a33a1992ff": "/npm.intl-relativeformat.8dd32a5e5a16117331c4.chunk.js",
    "887cab2da20429cf4c52af71335f0a071e698b91": "/npm.jss.f441ce707c2086f4dbf8.chunk.js",
    "bc1b3be8ba623e2c865c098b49e46c4e5cc272c8": "/npm.material-ui.47aa6a073ca053c6a6fd.chunk.js",
    "474988c51aa1d0a7706cdd4bb5e198822a3311be": "/npm.promise.733a52a4b24f86e30b32.chunk.js",
    "9f1252d482503a85c26e3649d66c83f18e153a18": "/npm.prop-types.00bbae956717cc1050e2.chunk.js",
    "9a19949ba5dcba89c5462a4acaa175558648c583": "/npm.react-app-polyfill.83ebef0577be4f8cc587.chunk.js",
    "1a47665794ea6da17dc74a8e96924a52b1152865": "/npm.react-intl.741dd49add785b9d27b0.chunk.js",
    "62b3b61b2882bd9b4f5590d1682fd03cb844012b": "/runtime.eb52123d42dd1870a1e1.js",
    "970c3537d80d22245a53ed65a3f121edda624c55": "/15.f5be83ad214c3ce47e90.chunk.js",
    "5538539ce0d4e3d0252a7452688e1dad132d6102": "/16.6034045e6580999510bb.chunk.js",
    "73361e27c453f7b1dd0e0150c1885f3d324eeefa": "/17.d6848cc7cc19eb7fbec4.chunk.js",
    "f9588f528311313abf82aeae4dc20dd0b8e3ca43": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "3/8/2021, 2:24:03 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });